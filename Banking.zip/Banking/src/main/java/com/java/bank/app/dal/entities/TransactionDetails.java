package com.java.bank.app.dal.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import javax.persistence.Table;

@Entity
@Table(name="transaction_details")
public class TransactionDetails {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int transactionId;
	private Date transactionDate;
	private Long accountNo;
	private String Description;
	private Double Withdrawal;
	private Double Deposit;
	private Double Balance;
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public Double getWithdrawal() {
		return Withdrawal;
	}
	public void setWithdrawal(Double withdrawal) {
		Withdrawal = withdrawal;
	}
	public Double getDeposit() {
		return Deposit;
	}
	public void setDeposit(Double deposit) {
		Deposit = deposit;
	}
	public Double getBalance() {
		return Balance;
	}
	public void setBalance(Double balance) {
		Balance = balance;
	}
	
	public Long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(Long accountNo) {
		this.accountNo = accountNo;
	}
	@Override
	public String toString() {
		return "TransactionDetails [transactionId=" + transactionId + ", transactionDate=" + transactionDate
				+ ", accountNo=" + accountNo + ", Description=" + Description + ", Withdrawal=" + Withdrawal
				+ ", Deposit=" + Deposit + ", Balance=" + Balance + "]";
	}
	
	
}
