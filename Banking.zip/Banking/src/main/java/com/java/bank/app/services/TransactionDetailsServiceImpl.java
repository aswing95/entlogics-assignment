package com.java.bank.app.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.bank.app.dal.entities.BankAccount;
import com.java.bank.app.dal.entities.TransactionDetails;
import com.java.bank.app.dal.repos.TransactionDetailsRepo;
@Service
public class TransactionDetailsServiceImpl implements TransactionDetailsService {
	
	@Autowired
	TransactionDetailsRepo transdetrep;

	@Override
	public TransactionDetails saveTransaction(TransactionDetails trans) {
		Double deposit=0.0;
		Double balance=0.0;
		Double Withdraw=0.0;
		if(trans.getDeposit()!=0)
		{
			deposit=trans.getDeposit();
			balance=trans.getBalance();
			trans.setBalance(deposit+balance);
		}
		else if(trans.getWithdrawal()!=0)
		{
			if(trans.getWithdrawal()<=trans.getBalance())
			{
				Withdraw=trans.getWithdrawal();
				balance=trans.getBalance();
				trans.setBalance(balance-Withdraw);
			}
			else
			{
				System.out.println("Insuffient Balance in Account");
			}
				
			
		}
		return transdetrep.save(trans);
	}

	@Override
	public List<TransactionDetails> getTransactions(Long accountno) {
		List<TransactionDetails> transactions=transdetrep.findAll();
		List<TransactionDetails> transactionsList=new ArrayList<TransactionDetails>();
		for(TransactionDetails tran:transactions)
		{
			if(tran.getAccountNo()==accountno)
			transactionsList.add(tran);
		}
		return transactionsList;
	}

	@Override
	public Integer deleteTransaction(TransactionDetails transdet) {
		List<TransactionDetails> findAll = transdetrep.findAll();
		for(TransactionDetails transdeta:findAll)
		{
			if(transdeta.getAccountNo()==transdet.getAccountNo())
			{
				transdetrep.delete(transdet);
			}
		}
		return transdet.getTransactionId();
	}

	
}
