package com.java.bank.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.java.bank.app.dal.entities.User;
import com.java.bank.app.dal.repos.UserRepo;
import com.java.bank.app.services.UserService;

@Controller
public class UserController {
	@Autowired
	private UserService userservice;
	@Autowired
	private UserRepo userrep;

	@RequestMapping("/showCreate")
	public String showCreate()
	{
		return "createUser";
	}
	
	@RequestMapping("/saveUser")
	public String saveUser(@ModelAttribute("User")User user,ModelMap modelmap) {
		User u=userservice.saveUser(user);
		String msg="User Saved with id"+u.getUserId();
		modelmap.addAttribute("msg", msg);
		return "createUser";
	}
	@RequestMapping(value = "/login",method=RequestMethod.POST)
	public String loginUser(@RequestParam("Username")String Username,@RequestParam("Password")String password,ModelMap modelmap)
	{
		User user = userrep.findByUsername(Username);
		if(user.getPassword().equals(password))
		{
			return "displayBankAccounts";
		}
		else
		{
			modelmap.addAttribute("msg", "Invalid username or password");
		}
		return "login";
	}
}
