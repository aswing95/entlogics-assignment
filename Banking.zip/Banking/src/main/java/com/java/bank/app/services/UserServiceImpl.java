package com.java.bank.app.services;

import org.springframework.beans.factory.annotation.Autowired;

import com.java.bank.app.dal.entities.User;
import com.java.bank.app.dal.repos.UserRepo;

public class UserServiceImpl implements UserService {
	@Autowired
	private UserRepo userrepo;

	@Override
	public User saveUser(User user) {
		 userrepo.save(user);
		 return user;

	}

}
