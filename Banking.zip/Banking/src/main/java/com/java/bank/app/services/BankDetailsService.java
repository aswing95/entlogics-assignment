package com.java.bank.app.services;

import java.util.List;

import com.java.bank.app.dal.entities.BankAccount;

public interface BankDetailsService {

	public BankAccount saveBankAccount(BankAccount bankacc);
	public List<BankAccount> getBankAccounts();
	public void deleteBankAccount(BankAccount bankacc);
}
