package com.java.bank.app.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.bank.app.dal.entities.BankAccount;
import com.java.bank.app.dal.repos.BankAccountRepo;
@Service
public class BankDetailsServiceImpl implements BankDetailsService {

	@Autowired
	BankAccountRepo bankaccrep;
	
	@Override
	public BankAccount saveBankAccount(BankAccount bankacc) {
		
		return bankaccrep.save(bankacc);
	}

	@Override
	public List<BankAccount> getBankAccounts() {
		// TODO Auto-generated method stub
		return bankaccrep.findAll();
	}

	@Override
	public void deleteBankAccount(BankAccount bankacc) {
		// TODO Auto-generated method stub
		 bankaccrep.delete(bankacc);
	}

}
