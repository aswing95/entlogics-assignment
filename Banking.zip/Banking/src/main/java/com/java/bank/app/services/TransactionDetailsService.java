package com.java.bank.app.services;

import java.util.List;
import com.java.bank.app.dal.entities.TransactionDetails;

public interface TransactionDetailsService {

	public TransactionDetails saveTransaction(TransactionDetails trans);
	public List<TransactionDetails> getTransactions(Long accountno);
	public Integer deleteTransaction(TransactionDetails transdet);
	
	
}
