package com.java.bank.app.services;

import com.java.bank.app.dal.entities.User;

public interface UserService {

	public User saveUser(User user);
}
