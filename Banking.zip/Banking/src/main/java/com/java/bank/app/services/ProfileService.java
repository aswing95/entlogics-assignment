package com.java.bank.app.services;

import java.util.List;

import com.java.bank.app.dal.entities.Profile;

public interface ProfileService {

	public Profile getProfileByName(String name);
	public Profile saveProfile(Profile profile);
	public void deleteProfile(Profile profile);
}
