package com.java.bank.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.java.bank.app.dal.entities.Profile;
import com.java.bank.app.services.ProfileService;

@Controller
public class ProfileController {

	@Autowired
	private ProfileService profileser;
	@RequestMapping("/displayProfile")
	public String displayProfile(@RequestParam("name")String name,ModelMap modelmap)
	{
		Profile profileByName = profileser.getProfileByName(name);
		modelmap.addAttribute("Profile", profileByName);
		return "displayProfile";
	}
	@RequestMapping("/showAdd")
	public String showAdd()
	{
		return "addProfile";
	}
	@RequestMapping("/addProfile")
	public String addProfile(@RequestParam("Profile")Profile profile,ModelMap modelmap)
	{
		Profile saveProfile = profileser.saveProfile(profile);
		modelmap.addAttribute("msg", "The profile is added with name "+saveProfile.getName());
		return "addProfile";
	}
	@RequestMapping("/deleteProfile")
	public void deleteProfile(@RequestParam("Profile")Profile profile)
	{
		profileser.deleteProfile(profile);
		
	}
	
}
