package com.java.bank.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.java.bank.app.dal.entities.BankAccount;
import com.java.bank.app.dal.entities.TransactionDetails;
import com.java.bank.app.services.TransactionDetailsService;

@Controller
public class TransactionDetailsController {

	@Autowired
	private TransactionDetailsService transdetserv;
	@RequestMapping("/showCompleteDetails")
	public String showTransactions(@RequestParam("BankAccount")BankAccount bacc,ModelMap modelmap)
	{
		List<TransactionDetails> transactions = transdetserv.getTransactions(bacc.getAccountNo());
		modelmap.addAttribute("transactions", transactions);
		return "displayTransactions";
		
	}
	@RequestMapping("/DeleteTransaction")
	public String deleteTransaction(@RequestParam("TransDetail")TransactionDetails transdet,ModelMap modelmap)
	{
		Integer deleteTransaction = transdetserv.deleteTransaction(transdet);
		modelmap.addAttribute("msg", "The transaction with id"+deleteTransaction+"is deleted");
		return "dispalyTransactions";
	}
	@RequestMapping("/addTrans")
	public String addTransaction()
	{
		return "addTransaction";
	}
	@RequestMapping("/saveTrans")
	public String saveTransaction(@RequestParam("TransactionDetails")TransactionDetails trans,ModelMap modelmap)
	{
		transdetserv.saveTransaction(trans);
		modelmap.addAttribute("msg", "Transaction saved with id: "+trans.getTransactionId());
		return "addTransaction";
	}
}
