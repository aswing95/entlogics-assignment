package com.java.bank.app.dal.entities;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Profile {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="customer_id")
	private int customerId;
	@Column(name="name")
	private String Name;
	@Column(name="address")
	private String Address;
	@Column(name="phone")
	private String Phone;
	@Column(name="email")
	private String Email;
	
	
	
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public void setPhone(String phone) {
		Phone = phone;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getPhone() {
		return Phone;
	}
	
	public String getEmail() {
		return Email;
	}
	
	public void setEmail(String email) {
		Email = email;
	}
	
	
	
	@Override
	public String toString() {
		return "Profile [customerId=" + customerId + ", Name=" + Name + ", Address=" + Address + ", Phone=" + Phone
				+ ", Email=" + Email +   "]";
	}
	

}
