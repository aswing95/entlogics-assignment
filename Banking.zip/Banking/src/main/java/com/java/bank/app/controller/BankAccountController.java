package com.java.bank.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.java.bank.app.dal.entities.BankAccount;
import com.java.bank.app.services.BankDetailsService;

public class BankAccountController {

	@Autowired
	private BankDetailsService bankdetserv;
	@RequestMapping("/bankAccounts")
	public String getBankAccounts(ModelMap modelmap)
	{
		
		List<BankAccount> bankAccounts = bankdetserv.getBankAccounts();
		modelmap.addAttribute("BankAccount", bankAccounts);
		return "displayBankAccounts";
	}
	@RequestMapping("/addBank")
	public String returnSave()
	{
		return "addBank";
	}
	@RequestMapping("/saveBank")
	public String saveBankAccount(BankAccount bankacc,ModelMap modelmap)
	{
	    bankdetserv.saveBankAccount(bankacc);
		modelmap.addAttribute("msg", "The bank account add with bankId"+bankacc.getBankId());
		return "displayBankAccounts";
	}
	@RequestMapping("/deleteBankDetails")
	public void deleteBank(BankAccount bankacc)
	{
		bankdetserv.deleteBankAccount(bankacc);
	}
}

