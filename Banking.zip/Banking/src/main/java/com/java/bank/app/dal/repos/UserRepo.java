package com.java.bank.app.dal.repos;

import org.springframework.data.repository.CrudRepository;

import com.java.bank.app.dal.entities.User;

public interface UserRepo extends CrudRepository<User, Integer> {

	User findByUsername(String username);

}
