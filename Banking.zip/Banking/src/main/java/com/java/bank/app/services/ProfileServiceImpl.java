package com.java.bank.app.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.bank.app.dal.entities.Profile;
import com.java.bank.app.dal.repos.ProfileRepo;

@Service
public class ProfileServiceImpl implements ProfileService {
	@Autowired 
	ProfileRepo profilerep;

	
	

	@Override
	public Profile saveProfile(Profile profile) {
		// TODO Auto-generated method stub
		return profilerep.save(profile);
	}



	@Override
	public void deleteProfile(Profile profile) {
		// TODO Auto-generated method stub
		profilerep.delete(profile);
	}



	@Override
	public Profile getProfileByName(String name) {
		// TODO Auto-generated method stub
		List<Profile> profiles=profilerep.findAll();
		
		for(Profile prof:profiles)
		{
			if(prof.getName().equals(name))
			{
				return prof;
			}
		}
		return null;
		
	}

	
}
