package com.java.bank.app.dal.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="bank_account")
public class BankAccount {

	@Id
	@Column(name="bank_id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int bankId;
	@Column(name="bank_name")
	private String bankName;
	@Column(name="account_no")
	private Long accountNo;
	@Column(name="account_holder")
	private String accountHolder;
	@Column(name="account_type")
	private String accountType;
	@Column(name="bank_code")
	private String bankCode;
	@Column(name="branch")
	private String branch;
	@OneToOne
	private Profile name;
	
	
	
	public int getBankId() {
		return bankId;
	}
	public void setBankId(int bankId) {
		this.bankId = bankId;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public Long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(Long accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountHolder() {
		return accountHolder;
	}
	public void setAccountHolder(String accountHolder) {
		this.accountHolder = accountHolder;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	
	
	
	public Profile getName() {
		return name;
	}
	public void setName(Profile name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "BankAccount [bankId=" + bankId + ", bankName=" + bankName + ", accountNo=" + accountNo
				+ ", accountHolder=" + accountHolder + ", accountType=" + accountType + ", bankCode=" + bankCode
				+ ", branch=" + branch + ", name=" + name + "]";
	}
	
	
	
}
