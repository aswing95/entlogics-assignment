package com.java.bank.app.dal.repos;



import org.springframework.data.jpa.repository.JpaRepository;



import com.java.bank.app.dal.entities.TransactionDetails;

public interface TransactionDetailsRepo extends JpaRepository<TransactionDetails, Integer> {

	
	 
	 
}
