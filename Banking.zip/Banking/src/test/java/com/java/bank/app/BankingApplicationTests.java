package com.java.bank.app;



import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.java.bank.app.dal.entities.Profile;
import com.java.bank.app.dal.entities.User;
import com.java.bank.app.dal.repos.ProfileRepo;
import com.java.bank.app.dal.repos.UserRepo;


@SpringBootTest
class BankingApplicationTests {
	@Autowired
	private UserRepo userrepo;
	@Autowired
	private ProfileRepo profilerepo;

	@Test
	public void testCreateUser()
	{
		User entity = new User();
		entity.setUsername("aswing95");
		entity.setPassword("12345");
		userrepo.save(entity);
	}
	
	@Test
	public void testCreateProfile()
	{
		 Profile entity = new Profile();
		 entity.setName("Aswin");
		 entity.setEmail("aswing95@gmail.com");
		 entity.setAddress("Bengaluru");
		 entity.setPhone("8296870972");
		 
		 
		profilerepo.save(entity);
	}
	
	@Test
	public void testRetrieveProfile()
	{
		Optional<Profile> findById = profilerepo.findById(1);
		System.out.println(findById);
	}
}
